# Cambios aplicados — AV Electronics

Proyecto compila y builda sin errores (`npm install && npm run build` verificado).

## 1. Paleta y tipografía (`src/styles/globals.css`, `tailwind.config.ts`, `index.html`)
- Azul "voltaje" (`#3454D1`) como color primario, cobre (`#E8833A`) como acento — igual que la guía de estilo entregada antes.
- Se agregaron pares semánticos `--color-success-bg/text`, `--color-warning-bg/text`, `--color-error-bg/text`, `--color-info-bg/text`, con variantes ajustadas para modo oscuro.
- Tipografía: Space Grotesk para títulos (h1-h6, automático) + Inter para texto — cargadas vía Google Fonts en `index.html`.
- Se agregó `.band-divider`, la banda tipo "resistencia" como elemento decorativo opcional.

## 2. Limpieza de colores fijos (9 archivos)
Se reemplazaron ~35 valores hex sueltos (`#D1FAE5`, `#FEF3C7`, `#DBEAFE`, etc.) por las variables semánticas nuevas en:
`TiendasPage`, `CotizacionTable`, `HistorialPage`, `TarjetaProducto`, `ConfiguracionPage`, `UserCreateForm`, `UserList`, `PreguntasPage`, `CargaPage`.
Esto asegura que **toda** la app responda a la paleta nueva (y al modo oscuro), no solo las pantallas que ya usaban variables.

## 3. Stepper de progreso — `src/shared/components/Stepper.tsx` (nuevo)
Indicador horizontal "Cargar lista → Aclarar dudas → Cotización", con el paso actual resaltado y los completados en verde con check. Se agregó en `CargaPage`, `PreguntasPage` y `CotizacionPage` para que el usuario siempre sepa en qué paso está.

## 4. Bloque de ambigüedades — `src/shared/components/AmbiguedadesPanel.tsx` (nuevo)
Reemplaza el patrón anterior de una tarjeta separada por pregunta (`QuestionCard`) por **un solo bloque de aviso** (tono ámbar) con todas las preguntas y su respuesta en línea, tal como se pidió.

- **`CargaPage`**: ahora, al presionar "Finalizar" con ambigüedades pendientes (`AMBIGUITIES_PENDING`), el bloque aparece **inline, en la misma pantalla donde se arma la lista**, sin navegar a otra página. Al confirmar respuestas, se reintenta la creación de la cotización automáticamente.
  > Nota: esto asume que el backend devuelve `detail.session_id` en el error 409/422 de `AMBIGUITIES_PENDING` de `/cotizacion/desde-carrito`. Si el backend no lo incluye todavía, es el único ajuste de API pendiente para que este bloque funcione end-to-end — el fallback actual muestra el mensaje de error genérico como antes.
- **`PreguntasPage`**: se migró al mismo componente, para que el flujo se vea idéntico si se llega ahí por otra vía.

## Archivos nuevos
- `src/shared/components/Stepper.tsx`
- `src/shared/components/AmbiguedadesPanel.tsx`

## Archivos modificados
- `src/styles/globals.css`, `tailwind.config.ts`, `index.html`
- `src/modules/carga/CargaPage.tsx`
- `src/modules/preguntas/PreguntasPage.tsx`
- `src/modules/cotizacion/CotizacionPage.tsx`
- `src/modules/admin/TiendasPage.tsx`, `ConfiguracionPage.tsx`
- `src/modules/cotizacion/components/CotizacionTable.tsx`
- `src/modules/historial/HistorialPage.tsx`
- `src/modules/carga/components/TarjetaProducto.tsx`
- `src/modules/usuarios/components/UserCreateForm.tsx`, `UserList.tsx`

## Pendiente / sugerido para una siguiente pasada
- Dashboard de inicio (hoy no existe landing, entra directo a `/carga`).
- Code-splitting de `pdf.worker` y `xlsx` (chunks >500kB, no relacionado al rediseño, ya existía).
- `src/modules/preguntas/components/QuestionCard.tsx` quedó sin uso — se puede borrar si no lo necesitas en otro lugar.
