import { AlertTriangle, Loader2 } from 'lucide-react'
import type { Pregunta } from '@/shared/types'

interface AmbiguedadesPanelProps {
  preguntas: Pregunta[]
  respuestas: Record<number, string>
  onChange: (preguntaId: number, value: string) => void
  onSubmit: () => void
  isSending?: boolean
  error?: string | null
  /** Texto opcional para personalizar el título según dónde se use el panel */
  titulo?: string
}

/**
 * Bloque único que agrupa todas las preguntas de aclaración generadas para
 * la lista actual. Reemplaza el patrón anterior de una tarjeta separada por
 * pregunta: aquí todo vive en un solo panel de "aviso" (tono ámbar), como un
 * bloque de texto legible con la respuesta pegada a cada pregunta.
 *
 * Pensado para aparecer inline, en el mismo lugar donde el usuario está
 * armando su lista (CargaPage), en el momento en que se detectan las
 * ambigüedades — no en una página aparte a la que hay que navegar.
 */
export default function AmbiguedadesPanel({
  preguntas,
  respuestas,
  onChange,
  onSubmit,
  isSending = false,
  error,
  titulo,
}: AmbiguedadesPanelProps) {
  if (preguntas.length === 0) return null

  const pendientes = preguntas.filter((p) => !respuestas[p.id]?.trim()).length

  return (
    <div
      className="rounded-xl border overflow-hidden"
      style={{ borderColor: 'var(--color-warning-text)', backgroundColor: 'var(--color-warning-bg)' }}
    >
      <div className="px-4 pt-4 pb-3 flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: 'var(--color-warning-text)' }} />
        <div>
          <h4 className="text-sm font-bold" style={{ color: 'var(--color-warning-text)' }}>
            {titulo ?? `Necesitamos que aclares ${preguntas.length === 1 ? 'esto' : `${preguntas.length} cosas`} antes de cotizar`}
          </h4>
          <p className="text-xs mt-0.5" style={{ color: 'var(--color-text-muted)' }}>
            Responde para que podamos buscar el producto exacto en cada tienda.
          </p>
        </div>
      </div>

      <div
        className="rounded-lg mx-4 mb-4 divide-y"
        style={{ backgroundColor: 'var(--color-surface)', borderColor: 'var(--color-border)' }}
      >
        {preguntas.map((p, idx) => (
          <div key={p.id} className="flex flex-col sm:flex-row sm:items-center gap-2.5 px-4 py-3" style={{ borderColor: 'var(--color-border)' }}>
            <div className="flex-1 min-w-0">
              <span className="text-xs font-bold mr-1.5" style={{ color: 'var(--color-text-muted)' }}>
                {idx + 1}.
              </span>
              <span className="text-sm" style={{ color: 'var(--color-text)' }}>
                {p.pregunta}
              </span>
            </div>
            <input
              type="text"
              value={respuestas[p.id] ?? ''}
              onChange={(e) => onChange(p.id, e.target.value)}
              disabled={isSending}
              placeholder="Tu respuesta..."
              className="w-full sm:w-56 flex-shrink-0 px-3 py-2 rounded-lg border outline-none text-sm transition-colors"
              style={{ borderColor: 'var(--color-border)', backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}
            />
          </div>
        ))}
      </div>

      {error && (
        <div className="mx-4 mb-3 text-xs font-medium" style={{ color: 'var(--color-error-text)' }}>
          {error}
        </div>
      )}

      <div className="px-4 pb-4 flex items-center justify-between gap-3">
        <span className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
          {pendientes === 0 ? 'Todo listo' : `${pendientes} de ${preguntas.length} sin responder`}
        </span>
        <button
          onClick={onSubmit}
          disabled={isSending || pendientes > 0}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          style={{ backgroundColor: 'var(--color-primary)' }}
        >
          {isSending ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" /> Enviando...
            </>
          ) : (
            'Confirmar y continuar'
          )}
        </button>
      </div>
    </div>
  )
}
