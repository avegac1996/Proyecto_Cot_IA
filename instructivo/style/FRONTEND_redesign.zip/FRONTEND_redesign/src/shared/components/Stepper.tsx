import { Check } from 'lucide-react'

export interface Step {
  id: string
  label: string
}

interface StepperProps {
  steps: Step[]
  currentId: string
  /** ids of steps that should render as "completed" even if not currentId (e.g. skipped) */
  completedIds?: string[]
}

/**
 * Indicador de progreso horizontal para el flujo Cargar -> Aclarar dudas -> Cotización.
 * Se muestra en la parte superior de cada página del flujo para que el usuario
 * siempre sepa en qué paso está y qué falta.
 */
export default function Stepper({ steps, currentId, completedIds = [] }: StepperProps) {
  const currentIndex = steps.findIndex((s) => s.id === currentId)

  return (
    <div className="flex items-center w-full" role="list" aria-label="Progreso de la cotización">
      {steps.map((step, idx) => {
        const isCompleted = completedIds.includes(step.id) || idx < currentIndex
        const isCurrent = step.id === currentId
        const isLast = idx === steps.length - 1

        return (
          <div key={step.id} className={`flex items-center ${isLast ? '' : 'flex-1'}`}>
            <div className="flex items-center gap-2" role="listitem" aria-current={isCurrent ? 'step' : undefined}>
              <div
                className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold transition-colors"
                style={{
                  backgroundColor: isCompleted ? 'var(--color-success-text)' : isCurrent ? 'var(--color-primary)' : 'var(--color-bg)',
                  color: isCompleted || isCurrent ? '#fff' : 'var(--color-text-muted)',
                  border: isCompleted || isCurrent ? 'none' : '1.5px solid var(--color-border)',
                }}
              >
                {isCompleted ? <Check className="w-3.5 h-3.5" /> : idx + 1}
              </div>
              <span
                className="text-xs font-medium whitespace-nowrap hidden sm:inline"
                style={{ color: isCurrent ? 'var(--color-text)' : 'var(--color-text-muted)' }}
              >
                {step.label}
              </span>
            </div>
            {!isLast && (
              <div
                className="flex-1 h-[2px] mx-3 rounded-full transition-colors"
                style={{ backgroundColor: isCompleted ? 'var(--color-success-text)' : 'var(--color-border)' }}
              />
            )}
          </div>
        )
      })}
    </div>
  )
}
