/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#EEF1FC',
          100: '#DCE3F9',
          200: '#B9C7F3',
          300: '#8FA3EA',
          400: '#5B7AE8',
          500: '#3454D1',
          600: '#2941A8',
          700: '#1F327F',
          800: '#182658',
          900: '#141B33',
        },
        accent: {
          50: '#FDF3EA',
          100: '#FBE3CC',
          400: '#EEA268',
          500: '#E8833A',
          600: '#CC6D28',
          700: '#A8571F',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['"Space Grotesk"', 'Inter', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
